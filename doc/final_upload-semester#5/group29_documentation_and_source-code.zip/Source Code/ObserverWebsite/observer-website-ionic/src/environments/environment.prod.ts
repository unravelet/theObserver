export const environment = {
  production: true,
  hmr: false,
  http: {
    apiUrl: "",
  },
  mqtt: {
    server: "4ac0ff29055441c8bbfa3caf55826e16.s1.eu.hivemq.cloud",
    protocol: "wss",
    port: 8884
  }
};
